public class Transaction {

    private String stockSymbol;
    private int quantity;
    private double price;
    private String type;

    public Transaction(String stockSymbol, int quantity, double price, String type) {
        this.stockSymbol = stockSymbol;
        this.quantity = quantity;
        this.price = price;
        this.type = type;
    }

    public void displayTransaction() {
        System.out.println(
            type + " | " +
            stockSymbol + " | Qty: " +
            quantity + " | Price: " + price
        );
    }
}