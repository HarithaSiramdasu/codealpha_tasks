import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

public class HotelManagementSystem {

    ArrayList<Room> rooms;
    ArrayList<Reservation> reservations;
    Scanner sc = new Scanner(System.in);

    // Constructor
    public HotelManagementSystem() {

        rooms = new ArrayList<>();
        reservations = new ArrayList<>();

        initializeRooms();
        loadBookings();
    }

    // Initialize Rooms
    public void initializeRooms() {

        rooms.add(new Room(101, "Standard", 2000));
        rooms.add(new Room(102, "Standard", 2000));

        rooms.add(new Room(201, "Deluxe", 3500));
        rooms.add(new Room(202, "Deluxe", 3500));

        rooms.add(new Room(301, "Suite", 5000));
        rooms.add(new Room(302, "Suite", 5000));
    }

    // Display all rooms
    public void displayRooms() {

        System.out.println("\n===== ALL ROOMS =====");

        for (Room room : rooms) {
            room.displayRoom();
        }
    }

    // Search rooms
    public void searchRooms() {

        System.out.print("Enter Room Type (Standard/Deluxe/Suite): ");
        String type = sc.next();

        boolean found = false;

        System.out.println("\nAvailable Rooms:");

        for (Room room : rooms) {

            if (room.getRoomType().equalsIgnoreCase(type)
                    && room.isAvailable()) {

                room.displayRoom();
                found = true;
            }
        }

        if (!found) {
            System.out.println("No rooms available.");
        }
    }

    // Book room
    public void bookRoom() {

        System.out.print("Enter Customer Name: ");
        String name = sc.next();

        System.out.print("Enter Phone Number: ");
        String phone = sc.next();

        System.out.print("Enter Room ID: ");
        int roomId = sc.nextInt();

        System.out.print("Enter Number of Days: ");
        int days = sc.nextInt();

        for (Room room : rooms) {

            if (room.getRoomId() == roomId && room.isAvailable()) {

                double totalAmount = room.getPrice() * days;

                Payment payment = new Payment();

                if (payment.processPayment(totalAmount)) {

                    int bookingId = reservations.size() + 1001;

                    Reservation reservation =
                            new Reservation(
                                    bookingId,
                                    name,
                                    roomId,
                                    room.getRoomType(),
                                    days,
                                    totalAmount,
                                    "Paid"
                            );

                    reservations.add(reservation);

                    room.setAvailable(false);

                    System.out.println("\nBooking Successful!");
                    System.out.println("Booking ID: " + bookingId);
                }

                return;
            }
        }

        System.out.println("Room not available.");
    }

    // View booking details
    public void viewBooking() {

        System.out.print("Enter Booking ID: ");
        int id = sc.nextInt();

        for (Reservation reservation : reservations) {

            if (reservation.getBookingId() == id) {

                System.out.println("\n===== BOOKING DETAILS =====");

                reservation.displayReservation();

                return;
            }
        }

        System.out.println("Booking not found.");
    }

    // Cancel booking
    public void cancelBooking() {

        System.out.print("Enter Booking ID: ");
        int id = sc.nextInt();

        Reservation booking = null;

        for (Reservation reservation : reservations) {

            if (reservation.getBookingId() == id) {

                booking = reservation;
                break;
            }
        }

        if (booking != null) {

            for (Room room : rooms) {

                if (room.getRoomId() == booking.getRoomId()) {

                    room.setAvailable(true);
                    break;
                }
            }

            reservations.remove(booking);

            System.out.println("Booking cancelled successfully.");
        }

        else {

            System.out.println("Booking not found.");
        }
    }

    // Save bookings to file
    public void saveBookings() {

        try {

            BufferedWriter bw =
                    new BufferedWriter(
                            new FileWriter("bookings.txt"));

            for (Reservation r : reservations) {

                bw.write(
                        r.getBookingId() + "," +
                        r.getCustomerName() + "," +
                        r.getRoomId() + "," +
                        r.getRoomType() + "," +
                        r.getDays() + "," +
                        r.getTotalAmount() + "," +
                        r.getPaymentStatus());

                bw.newLine();
            }

            bw.close();

            System.out.println("Bookings saved successfully.");
        }

        catch (IOException e) {

            System.out.println("Error saving bookings.");
        }
    }

    // Load bookings from file
    public void loadBookings() {

        try {

            BufferedReader br =
                    new BufferedReader(
                            new FileReader("bookings.txt"));

            String line;

            while ((line = br.readLine()) != null) {

                String[] data = line.split(",");

                Reservation reservation =
                        new Reservation(
                                Integer.parseInt(data[0]),
                                data[1],
                                Integer.parseInt(data[2]),
                                data[3],
                                Integer.parseInt(data[4]),
                                Double.parseDouble(data[5]),
                                data[6]);

                reservations.add(reservation);

                // Mark booked rooms unavailable
                for (Room room : rooms) {

                    if (room.getRoomId() == reservation.getRoomId()) {

                        room.setAvailable(false);
                        break;
                    }
                }
            }

            br.close();
        }

        catch (IOException e) {

            System.out.println("No previous bookings found.");
        }
    }
}