
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        HotelManagementSystem hotel = new HotelManagementSystem();

        int choice;

        do {

            System.out.println("\n===== HOTEL RESERVATION SYSTEM =====");
            System.out.println("1. Display Rooms");
            System.out.println("2. Search Rooms");
            System.out.println("3. Book Room");
            System.out.println("4. View Booking");
            System.out.println("5. Cancel Booking");
            System.out.println("6. Exit");

            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {

                case 1:
                    hotel.displayRooms();
                    break;

                case 2:
                    hotel.searchRooms();
                    break;

                case 3:
                    hotel.bookRoom();
                    break;

                case 4:
                    hotel.viewBooking();
                    break;

                case 5:
                    hotel.cancelBooking();
                    break;

                case 6:
                    hotel.saveBookings();
                    System.out.println("Thank you for using Hotel Reservation System.");
                    break;

                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 6);

        sc.close();
    }
}