public class Payment {

    public boolean processPayment(double amount) {

        System.out.println("Processing payment...");
        System.out.println("Payment of ₹" + amount + " successful.");

        return true;
    }
}
