public class Reservation {

    private int bookingId;
    private String customerName;
    private int roomId;
    private String roomType;
    private int days;
    private double totalAmount;
    private String paymentStatus;

    // Constructor
    public Reservation(int bookingId,
                       String customerName,
                       int roomId,
                       String roomType,
                       int days,
                       double totalAmount,
                       String paymentStatus) {

        this.bookingId = bookingId;
        this.customerName = customerName;
        this.roomId = roomId;
        this.roomType = roomType;
        this.days = days;
        this.totalAmount = totalAmount;
        this.paymentStatus = paymentStatus;
    }

    // Getters
    public int getBookingId() {
        return bookingId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public int getRoomId() {
        return roomId;
    }

    public String getRoomType() {
        return roomType;
    }

    public int getDays() {
        return days;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    // Display booking
    public void displayReservation() {

        System.out.println("Booking ID: " + bookingId);
        System.out.println("Customer Name: " + customerName);
        System.out.println("Room ID: " + roomId);
        System.out.println("Room Type: " + roomType);
        System.out.println("Days: " + days);
        System.out.println("Amount: ₹" + totalAmount);
        System.out.println("Payment Status: " + paymentStatus);
    }
}