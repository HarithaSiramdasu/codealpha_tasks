public class Room {

    private int roomId;
    private String roomType;
    private double price;
    private boolean available;

    // Constructor
    public Room(int roomId, String roomType, double price) {
        this.roomId = roomId;
        this.roomType = roomType;
        this.price = price;
        this.available = true;
    }

    // Getters
    public int getRoomId() {
        return roomId;
    }

    public String getRoomType() {
        return roomType;
    }

    public double getPrice() {
        return price;
    }

    public boolean isAvailable() {
        return available;
    }

    // Setter
    public void setAvailable(boolean available) {
        this.available = available;
    }

    // Display room details
    public void displayRoom() {
        System.out.println(
                roomId + " | " +
                roomType + " | ₹" +
                price + " | Available: " +
                available);
    }
}